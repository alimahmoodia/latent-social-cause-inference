%% this script computes the update-PE assymetry
clc; clear all; close all;
update_ch1{1} = [];
update_ch2{1} = [];
update_ch1{2} = [];
update_ch2{2} = [];
update_ch1{3} = [];
update_ch2{3} = [];
%
pe_ch1{1} = [];
pe_ch2{1} = [];
pe_ch1{2} = [];
pe_ch2{2} = [];
pe_ch1{3} = [];
pe_ch2{3} = [];

cdir = pwd;
data_path = fullfile(cdir(1:(end-19)),'Behaviour_data');
cd(data_path);
all_folders = dir(data_path);
filterelist = all_folders(~ismember({all_folders.name}, {'.', '..','.DS_Store'}));

plotdata = [];
for sub = 1  : size(filterelist)
    cd(data_path);
    cd((filterelist(sub).name));

    matfiles = dir('*mat');
    for session =  1 : 3
        load (matfiles(session).name);
        data.output.rating = data.output.rating*0.03;
       
        chs = [1 3];

        if sub == 17 | sub == 19 | sub == 20| sub == 22 | sub == 30 chs = [1 2]; end;
        if sub == 3 | sub == 10| sub == 25| sub == 26 chs = [2 3]; end;
        if sub == 24| sub == 16  chs = [2 1]; end
            

        for num_ch = 1 : 2
            rating_trs = find(data.output.rating_ch==chs(num_ch));
            for trial = 2 : length(rating_trs)
                ch = chs(num_ch);
                update(trial-1,1) = data.output.rating(rating_trs(trial)) - data.output.rating(rating_trs(trial-1));
                pe(trial-1,1) = data.output.outcome(rating_trs(trial)) - data.output.rating(rating_trs(trial-1));
                lr(trial-1,1) = update(trial-1,1)/pe(trial-1,1);
            end
            
            plotdata = [plotdata; update pe num_ch*ones(length(update),1) sub*ones(length(update),1) session*ones(length(update),1)];

            [pe_s,index] = sort(pe);
            update_sorted = update(index);
            lr_sorted = lr(index);
            if num_ch == 1
                temp = update_ch1{session};
                temp(end+1,:) = update_sorted';
                update_ch1{session} = temp;

                temp = pe_ch1{session};
                temp(end+1,:) = pe_s';
                pe_ch1{session} = temp;

            else
                temp = update_ch2{session};
                temp(end+1,:) = update_sorted';
                update_ch2{session} = temp;

                temp = pe_ch2{session};
                temp(end+1,:) = pe_s';
                pe_ch2{session} = temp;
            end
        end
    end

end

fulldata = [];
for blocktype = 1:2
    for sub = 1 : 33
        if blocktype ==1
            %% 
            % consider the first two blocks together
            u = [update_ch1{1,1} update_ch1{1,2}];
            pe = [pe_ch1{1,1} pe_ch1{1,2}];
            u2 = [update_ch2{1,1} update_ch2{1,2}];
            pe2 = [pe_ch2{1,1} pe_ch2{1,2}];
        else
            u = update_ch1{1,3};
            pe = pe_ch1{1,3};
            u2 = update_ch2{1,3};
            pe2 = pe_ch2{1,3};
        end

    
        pe_step = [-.3 -.05 .05 .3];
        data = [pe;pe2];
        pe_step = [-Inf quantile(data,0.33,'all') abs(quantile(data,0.67,'all')) Inf];
        for step = 1 : length(pe_step)-1
            ispe = find(pe(sub,:)>pe_step(step) & pe(sub,:)<pe_step(step+1));
            if size(ispe)
                u_ch11(sub,step) = mean(u(sub,ispe));
            else
                u_ch11(sub,step) = nan;
            end
            clear ispe
            ispe = find(pe2(sub,:)>pe_step(step) & pe2(sub,:)<pe_step(step+1));
            if size(ispe)
                u_ch21(sub,step) = mean(u2(sub,ispe));
            else
                u_ch21(sub,step) = nan;
            end
        end
    end
    fulldata = [fulldata; u_ch11 u_ch21 blocktype.*ones(sub,1)];
    %% 
    % plot
    figure
    plot(nanmean((u_ch11)),'r')
    hold on
    plot(nanmean((u_ch21)),'b')
    
    cd(cdir)

end

%% 

fulldata = array2table(fulldata, 'VariableNames',{'w_n','w_0','w_p','b_n','b_0','b_p','blocktype'});
writetable(fulldata,fullfile(cdir,"data_asym.txt"));

function M = fit_A3(inp,sub)
% fit particle-filter version of VKF
cdir = pwd;
if nargin<1, inp = 0; end
%nn = inp(1);


%nn = 1:72;
nn = 1;
fitcat = 'model_choice_2params_2blocks';
simul = 0;
if simul == 0
    mname = 'modeling';
elseif simul == 1
    mname = 'simul';
end

bmc = inp==0;
%--------------
basedir = pwd;
dataPath = fullfile(basedir,'Social_CA_Behaviour');
%subject = sub;
%subpath = ['S',num2str(sub)]
datadir = fullfile([dataPath '/' sub{1}]);
pipedir = fullfile(datadir,'pipedir'); 
if ~pipedir makedir(pipedir); end
cd(datadir);
matfiles = dir('*mat');

    d1 = load(matfiles(1).name);
     d2 = load(matfiles(2).name); 

     ch1 = [d1.data.output.ch1;d2.data.output.ch1];
     ch2 = [d1.data.output.ch2;d2.data.output.ch2];
     outcome = [d1.data.output.outcome;d2.data.output.outcome];
     resp = [d1.data.output.resp;d2.data.output.resp];
     data.output.ch1 = ch1;
     data.output.ch2 = ch2;
     data.output.outcome = outcome;
     data.output.resp = resp;
     data.datadir = datadir;
     clear ch1 ch2 resp outcome d1 d2 d3

cd(cdir)
        %subjdata      = load(fullfile(datadir,'simul_data.mat'));
        %data = subjdata.data;


sampling_range = [0.5 1];
sampling_init = 0.75;
fitting_d = 1;

%--------------
nsamples = 5000;
nparticles = 10000;

%if ~bmc
    %for s = 1:length(subject)]

        

    
        ndatapoints = 1*ones(size(data));
        %ndatapoints = 480*ones(size(data));
        fit_fit_pf(data, nn, fitcat, mname, @pf_model, @response_model, sampling_range, sampling_init, fitting_d, ndatapoints, nsamples, nparticles);
    %end
%�end

% model comparison
% if bmc
%     mnames    = {'vkf','hgf','rl','kf','pfvkf'};
%     
%     M =length(mnames);
%     lme = cell(1,M);
%     for i = 1:length(mnames)
%         fname = fullfile(pipedir, fitcat, sprintf('lap_%s.mat', mnames{i}) );
%         cbm   = load(fname);
%         cbm = cbm.cbm;
%         lme{i}  = cbm.output.log_evidence;
%     end
%     lme = cell2mat(lme);
%     M = fit_NHI(lme,mnames);
% end

end

function [loglik] = response_model(dv, params, data)
choice   = data.output.resp;

% if any(any(isnan(dv))) || any(any(~isfinite(dv)))
%     dv = zeros(size(dv));
% end

nt       = size(choice,1);
X        = dv(1:nt,:);
% Y        = choice==1;

loglik   = fit_A_response(X,params);

end

function [resp, pf] = pf_model(nparticles, params, data)
mu = params;
% v0 = params(2);

% choice   = data.output.resp;
% outcome  = data.output.outcome;

% outcome(:,1:2) = 2*outcome(:,1:2) - 1;
% outcome(:,3:4) = 2*outcome(:,3:4) + 1;
% outcome(choice==2) = -outcome(choice==2);
% 
% outcome(outcome==-1) = 0;

% N = size(outcome,1);
% resp1 = nan(N,4);
% pf = nan(N,4);

% for i=1:size(xQ,2)
%     [out,pf] = model_Soc_CA(nparticles,mu,data); %#ok<AGROW>
%     resp1(:,i) = out.responsibility1(1:end-1);
%     % vol(:,i) = v(1:end-1,:);
% end

[out,pf] = model_Soc_CA(nparticles,mu,data); %#ok<AGROW>

for trial = 1:length(out.outcome)
    if out.resp(trial) == 1
        resp(trial,1) = out.responsibility1(trial);
    elseif out.resp(trial) == 2
        resp(trial,1) = out.responsibility2(trial);
    end
end
  
% if any(any(isnan(xQ))) || any(any(~isfinite(xQ)))
%     xQ = zeros(size(xQ));
% end
end
clc; clear all; close all;
sub = {'S04','S05','S06','S07','S08','S09','S10','S11',...
    'S12','S13','S14','S15','S16','S17','S18','S19','S20',...
    'S21','S22','S23','S24','S25','S26','S27','S28','S29','S30','S31',...
    'S32','S33','S34','S35','S36','S37','S38','S39','S40'};


cluster = parcluster('local');
parfor (sub_num = 1 : size(sub,2),cluster)
    fit_A3(1,sub(sub_num));
end


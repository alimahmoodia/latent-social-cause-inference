function fit = model_data_resp(data,out)

    choice = data.output.resp -1;

    responsibility1 = out.responsibility1';
    responsibility2 = out.responsibility2';
    
    model_choice(find(responsibility1 > responsibility2),:) = 0;
    model_choice(find(responsibility2 > responsibility1),:) = 1;

    model_choice(find(responsibility2 == responsibility1),:) = randi([0,1],1);

    fit = sum(abs(choice - model_choice));

end
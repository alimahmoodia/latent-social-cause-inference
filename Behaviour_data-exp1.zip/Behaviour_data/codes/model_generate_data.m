function data = model_generate_data

% % load data
% data = load('joint_feedback.mat');
% data = data.data;
% o = data(:,3);
% characters = data(:,1:2);

% load data
% data = load('data.mat');
% data = data{1};

basedir = pwd;
dataPath = fullfile(basedir(1:(end-8)),'data');

pipedir = fullfile(basedir,'pipedir'); makedir(pipedir);

subject = {'S06'};
datadir = fullfile([dataPath '/' subject{1}]);
subjdata      = load(fullfile(datadir,'S6_CA_b2.mat'));
data = subjdata.data;
        
        
o = data.output.outcome;
ch1 = data.output.ch1;
ch2 = data.output.ch2;
characters = [ch1 ch2];


% set parameters
nparticles = 10000;
x_rng = [0 1];
sigma = 10^-4;
omega = 10^-4;
%mu = params(1);
mu = 1;

% model
state_model = @(particles,mu)pf_state_transition(particles, mu);
measurement_model = @pf_measurement_likelihood;

%rng(0);

pf = pf_initialize(state_model, measurement_model, nparticles, [x_rng; x_rng; x_rng]);


pf.particles = round(pf.particles);

pf.StateEstimationMethod = 'mean';
pf.ResamplingMethod = 'systematic';

N = length(o);
estimated = nan(N,3);

m = zeros(3,nparticles);
w = ones(3,nparticles);

for t=1:length(o)
    [i_z,c1,c2] = relevant_dimension(characters(t,:));
    characters_sorted(t,:) = [c1,c2];
    
    pf = pf_predict(pf,mu);
    [pf, idx] = pf_correct(pf,o(t),characters(t,:),m,w,sigma,omega);
    
    estimated(t,:) = pf.weights*pf.particles';
    
    z = pf.particles(i_z,:);
    
    rate_c(t,:) = pf.weights*m([c1;c2],:)';    
    resp_c(t,:) = [pf.weights*z' pf.weights*(1-z)'];    
    
    val(t,:) = pf.weights*m';
        
    [m,w] = kalman(pf.particles,o(t),characters(t,:),m(:,idx),w(:,idx),sigma,omega);      
end

rating = val;
responsibility = estimated; 

% the main output
x = [characters_sorted o rate_c resp_c];
T = array2table(x, 'VariableNames', {'character1','character2','outcome','rate1','rate2','responsibility1','responsibility2'});
% disp(T);


for i = 1:length(T.outcome)
    if data.output.ch1(i) == T.character1(i)
        data.output.rate1(i) = T.rate1(i);
        data.output.responsibility1(i) = T.responsibility1(i);
    elseif data.output.ch1(i) == T.character2(i)
        data.output.rate1(i) = T.rate2(i);
        data.output.responsibility1(i) = T.responsibility2(i);
    end
    
    if data.output.ch2(i) == T.character1(i)
        data.output.rate2(i) = T.rate1(i);
        data.output.responsibility2(i) = T.responsibility1(i);
    elseif data.output.ch2(i) == T.character2(i)
        data.output.rate2(i) = T.rate2(i);
        data.output.responsibility2(i) = T.responsibility2(i);
    end

end

for i = 1:length(T.outcome)
    if data.output.responsibility1(i) >= data.output.responsibility2(i)
        data.output.resp(i,1) = 1;
    else
        data.output.resp(i,1) = 2;
    end 
end

% for i = 1:length(T.outcome)
%     x = randperm(2);
%     data.output.resp(i,1)  = x(1);
% end

filename = [datadir '/simul_data'];
save(filename,'data');

end

%------------------------------
function particles = pf_state_transition(particles, mu)

u = [1 2 3];
z_1 = particles(1:3,:);

epsil = binornd(1,mu,length(u),size(particles,2));

z = z_1;
z(u,:) = epsil.*z_1(u,:) + (1-epsil).*(1-z_1(u,:));

particles(1:3,:) = z;
end

function likelihood = pf_measurement_likelihood(particles, measurement, characters, m, w, sigma, omega)
[i_z,c1,c2] = relevant_dimension(characters);
u = [c1,c2];

z1 = particles(i_z,:);
z2 = 1-z1;

P = w(u,:)+sigma;
v = P+omega;
v1 = v(1,:);
v2 = v(2,:);
m = m(u,:);
m1 = m(1,:);
m2 = m(2,:);

likelihood = normpdf(measurement,m1,sqrt(v1)).*z1 + normpdf(measurement,m2,sqrt(v2)).*z2;
end

function [i_z,c1,c2] = relevant_dimension(characters)
u = unique(characters);

if all(u==[1 2])
    i_z = 1;
elseif all(u==[1 3])
    i_z = 2;
elseif all(u==[2 3])
    i_z = 3;
end

c1 = min(u);
c2 = max(u);
end

function [mm, ww, z_c1]=kalman(particles,outcome,characters,m,w,sigma,omega)
[i_z,c1,c2] = relevant_dimension(characters);
u = [c1 c2];

z_c1 = particles(i_z,:);
z_c2 = 1-z_c1;
z = [z_c1;z_c2];

P = w(u,:)+sigma;
v = P+omega;

k = bsxfun(@times,P,v.^-1);
k = k.*z;

kk = zeros(3,size(m,2));
kk(u,:) = k;

mm = m + kk.*( outcome -m);
ww = (ones(3,1) - kk).*(w+sigma+omega);

end

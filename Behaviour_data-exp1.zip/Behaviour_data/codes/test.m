clc;
d=[];
for i = 1: 2
    d1 = load(files(1).name);
     d2 = load(files(2).name); 
end
     ch1 = [d1.data.output.ch1;d2.data.output.ch1];
     ch2 = [d1.data.output.ch2;d2.data.output.ch2];
     outcome = [d1.data.output.outcome;d2.data.output.outcome];
     outcome = [d1.data.output.resp;d2.data.output.resp];
%% script for behavioural data preprocessing
function mat = organise_data(data,block)
mat = [];
    for sessions = block(1):block(end)
        D = struct2table(data{sessions});

        for trial = 1:length(D.outcome)
            if D.position(trial) == 1
                D.first_ch(trial,1) = D.ch1(trial);
                D.second_ch(trial,1) = D.ch2(trial);
                D.first_ch_onset(trial,1) = D.ch1_onset(trial);
                D.second_ch_onset(trial,1) = D.ch2_onset(trial);
                D.resp_first_second(trial,1) = D.resp(trial);
            elseif D.position(trial) == -1
                D.first_ch(trial,1) = D.ch2(trial);
                D.second_ch(trial,1) = D.ch1(trial);
                D.first_ch_onset(trial,1) = D.ch2_onset(trial);
                D.second_ch_onset(trial,1) = D.ch1_onset(trial);
                D.resp_first_second(trial,1) = 3-D.resp(trial);
            end
        end
        D.block = block.*ones(trial,1);
        mat = [mat; D];

    end
end
function [loglik, beta] = fit_A_response(X,params)

beta = exp(params(1));
% beta1     = exp(abs(params(1)));
% beta2     = exp(abs(params(2)));
% beta = [beta1 beta2];

p = exp(beta.*X)./(exp(beta.*X)+exp(beta.*(1-X)));

% x1 = X(1:144);
% x2 = X(145:216);
% p1 = exp(beta1.*x1)./(exp(beta1.*x1)+exp(beta1.*(1-x1)));
% p2 = exp(beta2.*x2)./(exp(beta2.*x2)+exp(beta2.*(1-x2)));
% p = X;

loglik   = sum(sum(log(p+eps)));

% loglik1   = sum(sum(log(p1+eps)));
% loglik2   = sum(sum(log(p2+eps)));
% loglik = loglik1 + loglik2;
end
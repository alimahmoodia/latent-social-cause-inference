function x  = invfisher(fx)
x= (exp(2*fx)-1)./(exp(2*fx)+1);
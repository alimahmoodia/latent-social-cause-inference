%% this script computes prediction error, rating update etc. 
clc; clear all;
cdir = pwd;
data_path = fullfile(cdir(1:(end-19)),'Behaviour_data_exp1');

subject = {'S05','S06','S07','S08','S09','S10','S11',...
    'S12','S13','S14','S15','S16','S17','S18','S19','S20',...
    'S21','S22','S23','S24','S25','S27','S29','S30',...
    'S31','S32','S33','S34','S35','S36','S37','S38','S40'};

data_choice_do = 0;
data_rate_do = 0;
ch_rating_do = 1;




for sub = 1:size(subject,2)
    sub_path = fullfile(data_path,subject{sub}); 
    % load all data files
    files = dir(fullfile(sub_path,'*CA*b*.mat'));
    
    mat = [];
    % combine and preprocess data of all three blocks
    for block = 1:numel(files)
        % read data for each block
        data{block} = load(fullfile(sub_path,files(block).name)).data.output;
    end
    data = organise_data(data,[1 2 3]);
    data_subjects{sub} = data;
    clear data
end

clearvars -except data_subjects cdir subject data_choice_do data_rate_do ch_rating_do

%% data_choice
if data_choice_do
data_choice = [];
for sub = 1:length(subject)
    data = data_subjects{sub};

    for trial = 1 : length(data.outcome)
        choice(trial,1) = 3-data.resp_first_second(trial)-1;

        % compute prediction error for the first character
        ch1 = data.first_ch(trial);
        % look for the last trial where the second character is rated
        TrialFound = 0;
        trial_search = trial - 1;
        while (~ TrialFound)&&(trial_search ~= 0)
            if data.rating_ch(trial_search) == ch1
                TrialFound = 1;
            else
                trial_search = trial_search - 1;
            end
        end
        if trial_search == 0
           PE1(trial) = NaN;
        else
           PE1(trial) = abs(data.rating(trial_search)*0.03-data.outcome(trial));
        end

        % compute prediction error for the second character
        ch2 = data.second_ch(trial);
        TrialFound = 0;
        trial_search = trial - 1;
        % look for the last trial where the second character is rated
        while (~ TrialFound)&&(trial_search ~= 0)
            if data.rating_ch(trial_search) == ch2
                TrialFound = 1;
            else
                trial_search = trial_search - 1;
            end
        end
        if trial_search == 0
           PE2(trial) = NaN;
        else
           PE2(trial) = abs(data.rating(trial_search)*0.03-data.outcome(trial));
        end
        pe_diff(trial,1) = PE1(trial)-PE2(trial);

    end
    idx = ~isnan(pe_diff);
    data_choice = [data_choice; zscore(data.outcome(idx)) choice(idx) zscore(pe_diff(idx))...
        data.block(idx) sub*ones(sum(idx),1)];
end
% save data as a .csv file
data_choice = array2table(data_choice, 'VariableNames',...
    {'outcome','choice','pe_diff','block','subject'});
writetable(data_choice,fullfile(cdir,'data_choice.csv'),'Delimiter',',');

clearvars -except data_subjects cdir subject data_choice_do data_rate_do ch_rating_do
end
%% data_rate
if data_rate_do
data_rate = [];
for sub = 1:length(subject)
    data = data_subjects{sub};
    rating_trs = find(~isnan(data.rating_ch));

    % get the choice here
    for tr = 1 : length(data.resp)
        if data.resp_first_second(tr,1) == 1
            chosen_ch(tr,1) = data.first_ch(tr,1);
            unchosen_ch(tr,1) = data.second_ch(tr,1);
        elseif data.resp_first_second(tr,1) == 2
            chosen_ch(tr,1) = data.second_ch(tr,1);
            unchosen_ch(tr,1) = data.first_ch(tr,1);
        end
    end
    
    % loop through all rating trials to get rating, prediction error and
    % rating update
    outcome = data.outcome(rating_trs);
    rating = data.rating(rating_trs);
    for trial = 1 : length(rating_trs)
        ch = data.rating_ch(rating_trs(trial));
        resp(trial,1) = data.resp_first_second(rating_trs(trial))-1;
       if chosen_ch(rating_trs(trial)) == ch
            resp(trial,1) = 1;
        else
            resp(trial,1) = 0;
        end
        
        % find the previous trial where the same character is rated
        TrialFound = 0;
        trial_search = rating_trs(trial) - 1;
        while (~ TrialFound)&&(trial_search ~= 0)
            if data.rating_ch(trial_search) == ch
                TrialFound = 1;
            else
                trial_search = trial_search - 1;
            end
        end

        if trial_search == 0
           spe(trial,1) = NaN;
           update(trial,1) = NaN;
           abs_pe(trial,1) = NaN;
        else
            spe(trial,1) = data.outcome(rating_trs(trial)) - data.rating(trial_search)*0.03;
            update(trial,1) = data.rating(rating_trs(trial))*0.03 - data.rating(trial_search)*0.03;
            abs_pe(trial,1) = abs(spe(trial,1));
        end
    end
    idx = ~isnan(spe);
    data_rate = [data_rate; zscore(outcome(idx)) zscore(rating(idx))...
        zscore(spe(idx)) zscore(abs_pe(idx)) zscore(update(idx)) resp(idx)...
        data.block(idx) sub*ones(sum(idx),1)];
end
% save data as .csv file
data_rate = array2table(data_rate, 'VariableNames',...
    {'outcome','rating','spe','abs_pe','update','resp','block','subject'});
writetable(data_rate,fullfile(cdir,'data_rate.csv'),'Delimiter',',');

clearvars -except data_subjects cdir subject 
end
%% rating of characters 
if ch_rating_do
out = [];
for sub = 1:length(subject)
    data = data_subjects{sub};
    rating_trs = ~isnan(data.rating_ch);
    
    out = [out;data.rating_ch(rating_trs) data.rating(rating_trs) data.block(rating_trs) sub*ones(sum(rating_trs),1)];
end

% save data as .csv file
out = array2table(out, 'VariableNames',...
    {'ch','rating','block','subject'});
writetable(out,fullfile(cdir,'ch_rating.csv'),'Delimiter',',');

clearvars -except data_subjects cdir subject data_choice_do data_rate_do ch_rating_do
end

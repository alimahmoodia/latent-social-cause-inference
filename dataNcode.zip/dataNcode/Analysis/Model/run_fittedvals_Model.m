clc; clear all; close all;
%% this script replace the fitted parameters in the model and
%% save the data. Alim April 2022

cdir = pwd;
basedir = pwd;
dataPath = fullfile(basedir,'Social_CA_Behaviour');
subject = {'S04','S05','S06','S07','S08','S09','S10','S11',...
    'S12','S13','S14','S15','S16','S17','S18','S19','S20',...
    'S21','S22','S23','S24','S25','S26','S27','S28','S29','S30','S31',...
    'S32','S33','S34','S35','S36','S37','S38','S39','S40'};

nsamples = 100;
for sub = 1:size(subject,2)
    datadir = fullfile([dataPath '/' subject{sub}]);

    cd(datadir);
    matfiles = dir('*mat');

    %%
     d1 = load(matfiles(1).name);
     d2 = load(matfiles(2).name); 

     ch1 = [d1.data.output.ch1;d2.data.output.ch1];
     ch2 = [d1.data.output.ch2;d2.data.output.ch2];
     outcome = [d1.data.output.outcome;d2.data.output.outcome];
     resp = [d1.data.output.resp; d2.data.output.resp];
     position = [d1.data.output.position; d2.data.output.position];
     rating_ch = [d1.data.output.rating_ch; d2.data.output.rating_ch];
     rating = [d1.data.output.rating; d2.data.output.rating];
     data.output.ch1 = ch1;
     data.output.ch2 = ch2;
     data.output.outcome = outcome;
     data.output.resp = resp;
     data.output.position = position;
     data.output.rating_ch = rating_ch;
     data.output.rating = rating;
    %%
    load(fullfile(datadir,'pipedir','model_choice_2params_2blocks_v5','lap_modeling.mat'));

%     beta(sub,1) = cbm.output.parameters;
% 
%     load(fullfile(datadir,'pipedir','model_choice_2params_3rdblock','lap_modeling.mat'));
%     beta(sub,2) = cbm.output.parameters;
%     
     cd(cdir)
    
    for n = 1:nsamples
        
        [out(n), pf(n), m{n}, w{n}]=model_Soc_CA(10000, cbm.output.x_pf, data);
       
        correlation(n) = get_pe(data,out(n));
        
        %fit(n) = model_data_resp(data,out(n));

    end
    
    [~,i] = max(correlation);
    %[~,i] = min(fit);
    output.out = out(i);
    output.pf = pf(i);
    output.m = m{i};
    output.w = w{i};

filename=['v_2block_output_v5_HMMKF'];

cd(datadir)
save(filename,'output');

   clear matfiles
    cd(dataPath);

    fprintf('%s ',subject{sub});
end
cd(cdir);
function correlation = ev_correlation(data,out)


data = struct2table(data.output);
data.resp1 = out.responsibility1';
data.resp2 = out.responsibility2';
data.rate1 = out.rate1';
data.rate2 = out.rate2';

for trial = 1:length(data.outcome)
    if data.position(trial) == 1
        data.first_ch(trial,1) = data.ch1(trial);
        data.second_ch(trial,1) = data.ch2(trial);
        data.first_ch_resp(trial,1) = data.resp1(trial);
        data.second_ch_resp(trial,1) = data.resp2(trial);
        data.first_ch_rate(trial,1) = data.rate1(trial);
        data.second_ch_rate(trial,1) = data.rate2(trial);
    elseif data.position(trial) == -1
        data.first_ch(trial,1) = data.ch2(trial);
        data.second_ch(trial,1) = data.ch1(trial);
        data.first_ch_resp(trial,1) = data.resp2(trial);
        data.second_ch_resp(trial,1) = data.resp1(trial);
        data.first_ch_rate(trial,1) = data.rate2(trial);
        data.second_ch_rate(trial,1) = data.rate1(trial);
    end
end

model_first_ch_pe = data.outcome - data.first_ch_rate;
model_second_ch_pe = data.outcome - data.second_ch_rate;

model_pe_diff = abs(abs(model_first_ch_pe)-abs(model_second_ch_pe));



    for trial = 1 : length(data.outcome)
        %% compute PE1
        
        ch1 = data.first_ch(trial);
     
        TrialFound = 0;
        trial_search = trial - 1;
        while (~ TrialFound)&&(trial_search ~= 0)
            if data.rating_ch(trial_search) == ch1
                TrialFound = 1;
            else
                trial_search = trial_search - 1;
            end
        end
        if trial_search == 0
           data.first_ch_pe(trial,1) = NaN;
        else
             data.first_ch_pe(trial,1) = data.outcome(trial) - data.rating(trial_search)*0.03;
        end
        %% PE2
         ch2 = data.second_ch(trial);

        TrialFound = 0;
        trial_search = trial - 1;
        while (~ TrialFound)&&(trial_search ~= 0)
            if data.rating_ch(trial_search) == ch2
                TrialFound = 1;
            else
                trial_search = trial_search - 1;
            end
        end
        if trial_search == 0
            data.second_ch_pe(trial,1) = NaN;
        else
            data.second_ch_pe(trial,1) = data.outcome(trial) - data.rating(trial_search)*0.03;
        end

        data_pe_diff(trial,1) = abs(abs(data.first_ch_pe(trial)) - abs(data.second_ch_pe(trial)));
    end
    data_pe_diff(find(isnan(data_pe_diff))) = 0;

correlation = corr(model_pe_diff, data_pe_diff);
end
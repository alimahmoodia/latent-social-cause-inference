clc; clear all;

Path = pwd;
Path = fullfile(Path,'Social_CA_Behaviour');

subject = {'S04','S05','S06','S07','S08','S09','S10','S11',...
    'S12','S13','S14','S15','S16','S17','S18','S19','S20',...
    'S21','S22','S23','S24','S25','S26','S27','S28','S29','S30','S31',...
    'S32','S33','S34','S35','S36','S37','S38','S39','S40'};

corrPercent = [];

for sub = 1:size(subject,2)

    dataPath = [Path '/' subject{sub}];
    out = load([dataPath '/v_2block_output_v5_HMMKF']);
    out = out.output.out;
    
    responsibility1 = out.responsibility1';
    responsibility2 = out.responsibility2';
    
    model_choice = NaN(length(responsibility1),1);
%     model_choice(find(responsibility1 == 1)) = 0;
%     model_choice(find(responsibility2 == 1)) = 1;

    model_choice(find(responsibility1 > responsibility2)) = 0;
    model_choice(find(responsibility2 > responsibility1)) = 1;

    model_choice(find(responsibility2 == responsibility1)) = randi([0,1],1);

    files = dir(fullfile(dataPath,'*CA*b*.mat'));

    choice = [];
    for block = 1:2
        analysis = [];
        data = load([dataPath '/' files(block).name]);
        data = data.data;
       
        data = struct2table(data.output);
    
        choice = [choice; data.resp-1];
    
    end

    corrPercent =[corrPercent; subject(sub) 1 - sum(abs(choice - model_choice))/length(choice)];
    
    

end